﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CodeFirstApproach.Models;

namespace CodeFirstApproach.Controllers
{
    public class EmployeeController : Controller
    {
        private EmployeeDbContext db = new EmployeeDbContext();

        public ActionResult List()
        {
            ViewBag.Message = "Employee List";
            EmployeeViewModel model = new EmployeeViewModel();
            var employeeList = db.EmployeeTable.ToList();

            var empDetails = (from emp in employeeList
                              select new EmployeeViewModel()
                              {
                                  Id = emp.Id,
                                  Name = emp.Name,
                                  Age = emp.Age,
                                  Sex = ((Gender)emp.Sex).ToString()
                              }).ToList();

            return View(empDetails);
        }

        public ActionResult Details(int id)
        {
            EmployeeModel employee = db.EmployeeTable.Find(id);
            ViewBag.Message = "Details " + employee.Name;

            if (employee == null)
            {
                return View("notFound");
            }
            return View(employee);
        }

        [HttpPost]
        public ActionResult Create(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                int eValue = (int)model.Sex;
                db.EmployeeTable.Add(model);
                db.SaveChanges();
                return RedirectToAction("List");
            }

            return View(model);
        }
        
        public ActionResult Delete(int id)
        {
            EmployeeModel employee = db.EmployeeTable.Find(id);
            db.EmployeeTable.Remove(employee);
            db.SaveChanges();
            return Json(new { result = "success" });
        }

    }
}
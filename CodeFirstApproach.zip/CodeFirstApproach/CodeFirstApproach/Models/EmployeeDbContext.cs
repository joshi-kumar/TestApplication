﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CodeFirstApproach.Models
{
    public class EmployeeDbContext : DbContext
    {
        public EmployeeDbContext()
            : base("DefaultConnection")
        { }

        public DbSet<EmployeeModel> EmployeeTable { get; set; }   
    }
}
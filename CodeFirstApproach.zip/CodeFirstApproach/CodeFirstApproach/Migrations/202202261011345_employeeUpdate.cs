namespace CodeFirstApproach.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class employeeUpdate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.EmployeeModels", "Sex", c => c.Int(nullable: false));
            DropColumn("dbo.EmployeeModels", "ActionId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.EmployeeModels", "ActionId", c => c.Int(nullable: false));
            DropColumn("dbo.EmployeeModels", "Sex");
        }
    }
}

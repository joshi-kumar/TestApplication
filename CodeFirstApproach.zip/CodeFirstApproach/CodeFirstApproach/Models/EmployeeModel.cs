﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CodeFirstApproach.Models
{
    public class EmployeeModel
    {
        public int Id { get; set; }

        [Required]
        [Display(Description = "Name")]
        public string Name { get; set; }

        [Display(Description = "Age")]
        public int Age { get; set; }

        [Display(Description = "Gender")]
        public Gender Sex { get; set; }

        [DataType(DataType.MultilineText)]
        public string Address { get; set; }
    }

    public enum Gender
    {
        Male=1,
        Female=2
    }
}